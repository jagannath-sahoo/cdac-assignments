#include<stdio.h>
#include<stdlib.h>


int * bubbleSort(int *num);

int main()
{
	int num[] = {64, 34, 25, 12, 22, 11, 90};	
	
	return 0;
}

int * bubbleSort(int *num)

