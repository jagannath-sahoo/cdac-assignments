#include<stdio.h>

int main(){
	int a = 125;

	printf("%d\n",a%10);
	printf("%d\n",a/10);
	return 0;
}
