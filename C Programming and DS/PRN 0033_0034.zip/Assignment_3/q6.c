/* Q6. Formatted I/O*/

#include<stdio.h>


int main()
{
	int n,m,p;
	float a,c;
	/*printf("1.Enter number \n");
	scanf("%5d",&n);
	printf("%d",n);
	printf("2.Enter A number\n");
	scanf("%05d\n",&m);
	printf("%d",m);
	*/
	printf("3.Enter A number\n");
	scanf("%-1d",&p);
	printf("%d",p);
/*	printf("4.Enter a number\n");
	scanf("%8.2f",a);
	printf("%f",a);
	printf("5.Enter a number");
	scanf("%.2f",c);
	printf("%f",c);
	*/return 0;
}
