#include<stdio.h>
int main()
{

int n,i,a,sum=0;
	printf("Enter no. of terms");
	scanf("%d",&n);
	for(i=1;i<=n;i++){
		printf("Enter numbers");
	scanf("%d",&a);
	sum=sum+a;
	}
	printf("Sum is =%d",sum);
}
