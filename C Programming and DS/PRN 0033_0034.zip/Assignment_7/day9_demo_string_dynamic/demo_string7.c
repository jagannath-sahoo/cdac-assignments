#include<stdio.h>

int main(){
	printf("hello world");
	char *c="hello world";
	printf("123");

}
